﻿using System;

namespace q1
{
    class Program
    {
        static void Main()
        {

            Console.WriteLine("Hello, World!");
            Console.ReadKey();
        }
    }
}
