﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            Console.Write("Please enter your name :\n");
            a = Console.ReadLine();

            Console.WriteLine("Hello, '{0}' ", a);
            Console.ReadKey();
              
        }
    }
}
