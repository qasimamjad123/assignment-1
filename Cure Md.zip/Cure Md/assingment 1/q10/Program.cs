﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q9
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter the number of terms: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Fibonacci Sequence:");
            for (int i = 0; i < n; i++)
            {
                Console.Write(Fibonacci(i) + " ");
            }
            Console.ReadLine();
        }

        static int Fibonacci(int n)
        {
            if (n <= 1)
                return n;

            int a = 0, b = 1, c = 0;
            for (int i = 2; i <= n; i++)
            {
                c = a + b;
                a = b;
                b = c;
            }

            return b;
        }
    }
}
